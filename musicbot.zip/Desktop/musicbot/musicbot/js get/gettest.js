const youtube = require('scrape-youtube').default;

searchstring = "Never gonna give you up"

console.log(searchstring.slice(6));
youtube.search(searchstring).then((results)=>{
    console.log(results.videos[0].link)
});